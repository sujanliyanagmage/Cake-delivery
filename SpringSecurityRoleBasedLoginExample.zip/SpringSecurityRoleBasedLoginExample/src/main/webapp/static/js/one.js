/*This is a custom js file cleated to manipulate and form submissions of application.*/

$( document ).ready(function() {

$( '#one' ).click(function() {
	alert("HI");
});

});