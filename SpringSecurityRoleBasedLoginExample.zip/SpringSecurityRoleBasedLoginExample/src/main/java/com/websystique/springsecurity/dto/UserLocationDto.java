package com.websystique.springsecurity.dto;

import java.io.Serializable;

public class UserLocationDto implements Serializable {
	
	UserLocationDto(){
		
	}
	
	public UserLocationDto(String latitude,String longitude,String deliveryId) {
		this.latitude=latitude;
		this.longitude=longitude;
		this.deliveryId=deliveryId;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String latitude;

	private String longitude;

	private String deliveryId;

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

}
