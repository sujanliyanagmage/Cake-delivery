package com.websystique.springsecurity.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.websystique.springsecurity.dto.UserLocationDto;

@RestController
@RequestMapping(value = "/gpsTracker")
public class GetLocationController {

	private static List<UserLocationDto> geoLocations = new ArrayList<>();

	@RequestMapping(value = "/gew", method = RequestMethod.POST)
	public void getCurrentLocation1(@RequestBody UserLocationDto userLocationDto) {
		System.out.println("===================Testing==============" + userLocationDto.getDeliveryId());

	}

	@RequestMapping(value = "/cLocation", method = RequestMethod.GET)
	public UserLocationDto getcuurentLocation(@RequestParam("id") int id) {

		// add static place .
		geoLocations.add(new UserLocationDto("6.124593", "81.101074", "rider1"));
		geoLocations.add(new UserLocationDto("8.592200", "81.196793", "rider1"));
		geoLocations.add(new UserLocationDto("7.290572", "80.633728", "rider1"));

		geoLocations.add(new UserLocationDto("6.894070", "79.902481", "rider1"));
		geoLocations.add(new UserLocationDto("7.189464", "79.858734", "rider1"));
		geoLocations.add(new UserLocationDto("6.053519", "80.220978", "rider1"));
		geoLocations.add(new UserLocationDto("6.927079", "79.861244", "rider1"));
		geoLocations.add(new UserLocationDto("7.291418", "80.636696", "rider1"));

		System.out.println("counter-------" + geoLocations.size());

		UserLocationDto temp = geoLocations.get(id);


		System.out.println("currentsize-----------" + temp.getLatitude());

		return temp;

	}

}
